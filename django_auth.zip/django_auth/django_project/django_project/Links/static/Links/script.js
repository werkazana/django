document.querySelectorAll('.copy-link').forEach(button => {
    button.addEventListener('click', function() {
        let link = this.parentElement.querySelector('a').href;
        navigator.clipboard.writeText(link).then(() => {
            button.classList.add('copied');
            setTimeout(() => {
                button.classList.remove('copied');
            }, 1000);
        }); 
    });
});