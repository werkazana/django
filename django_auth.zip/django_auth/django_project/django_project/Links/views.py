from django.shortcuts import render, get_object_or_404, redirect
from django.http import Http404
from .models import Link

def index(request):
    latest_link_list = Link.objects.all()
    context = {"latest_link_list": latest_link_list}
    return render(request, "Links/index.html", context)

def link_redirect(request, short_id):
    try:
        link = get_object_or_404(Link, short_id=short_id)
        return redirect(link.original_url)
    except Http404:
        return render(request, "Links/404.html")

def delete_link(request, short_id):
    link = get_object_or_404(Link, short_id=short_id)
    link.delete()
    return redirect('Links:index')

