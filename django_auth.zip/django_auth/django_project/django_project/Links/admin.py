from django.contrib import admin
from .models import Link

admin.site.register(Link)
