from django.conf import settings
from django.db import models
from django.core.validators import URLValidator
from django.utils import timezone
from django.urls import reverse

class Link(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='links')
    original_url = models.URLField(validators=[URLValidator()], verbose_name="Docelowy adres URL")
    created_at = models.DateTimeField(default=timezone.now, verbose_name="Data utworzenia")
    short_id = models.AutoField(primary_key=True, verbose_name="Krótki link")

    def __str__(self):
        return f"{self.short_id}"